<?php
date_default_timezone_set('Asia/Shanghai');
// 允许的跨域请求方法
//header("Access-Control-Allow-Origin: *"); 
//header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS"); 
//header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
/*
 * DiyVod 订阅者配置接口
 * PHP 7.2+
 * APP POST: u=10位小写字母或数字做统计使用。
 * 安全：admin.php修改重命名，config.sjon重命名，登入密码也修改。
 * 如不想折腾,直接服务器配置使用宝塔服务器，只要安装7.2以上版本都可以运行。
 * PHP需要：
 * PDO
 * pdo_sqlite
 * sqlite3 一般宝塔都默认安装的。
 * admin.php  后台登入文件（密码自己代码修改）
 * index.php   需要post才能显示配置内容
 * config.json 生成的配置文件
 * diyvod.sqlite 统计订阅使用者 数据文件
 * 使用测试如能访问http(s)//你的域名或ip/admin.php那么就是正常。 
 * APP测试在接口添加http(s)//你的域名或ip/  
 * 如APP链接你的订阅接口测试无效，请开启php跨越使用。 
 */
define('DB_FILE', __DIR__ . '/diyvod.sqlite');
define('CONFIG_FILE', __DIR__ . '/config.json');

function output_json_error($code, $msg, $http_code) {
    http_response_code($http_code);
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode(
        array('code' => $code, 'msg' => $msg),
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
    );
    exit;
}

function load_config() {
    if (!is_file(CONFIG_FILE)) return null;
    $raw = @file_get_contents(CONFIG_FILE);
    if ($raw === false || trim($raw) === '') return null;
    $data = json_decode($raw, true);
    return is_array($data) ? $data : null;
}

function update_user($u) {
    if (!is_file(DB_FILE)) return;

    $now = date('Y-m-d H:i:s');
    $today = date('Y-m-d');

    try {
        $pdo = new PDO('sqlite:' . DB_FILE);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->exec('PRAGMA busy_timeout = 5000');

        $stmt = $pdo->prepare('SELECT u FROM users WHERE u=? LIMIT 1');
        $stmt->execute(array($u));
        $exists = $stmt->fetchColumn();

        if ($exists === false) {
            $stmt = $pdo->prepare(
                'INSERT INTO users (u, first_use_at, last_seen_at, last_use_date)
                 VALUES (?, ?, ?, ?)'
            );
            $stmt->execute(array($u, $now, $now, $today));
        } else {
            $stmt = $pdo->prepare(
                'UPDATE users SET last_seen_at=?, last_use_date=? WHERE u=?'
            );
            $stmt->execute(array($now, $today, $u));
        }
    } catch (Exception $e) {

    }
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    output_json_error(405, '404', 405);
}

$u = strtolower(trim(isset($_POST['u']) ? (string)$_POST['u'] : ''));

if (!preg_match('/^[a-z0-9]{8,10}$/', $u)) {
    output_json_error(400, 'u 404', 400);
}

update_user($u);

$config = load_config();
if ($config === null) {
    output_json_error(500, '配置文件读取失败', 500);
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode(
    $config,
    JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
);
