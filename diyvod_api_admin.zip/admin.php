<?php
session_start();
date_default_timezone_set('Asia/Shanghai');
define('ADMIN_PASSWORD', '123456');//登入密码请自主修改
define('DB_FILE', __DIR__ . '/diyvod.sqlite');//数据库文件
define('CONFIG_FILE', __DIR__ . '/config.json');//生成的配置文件

function h($v) {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

function default_config() {
    return array(
        'data' => array(
            'logo' => '',
            'name' => 'DiyVod',
            'weburl' => ''
        ),
        'tanchuang' => array(),
        'guanggao' => array(),
        'apiurl' => array(),
        'code' => 200,
        'msg' => 'success'
    );
}

function load_config() {
    if (!is_file(CONFIG_FILE)) return default_config();
    $raw = @file_get_contents(CONFIG_FILE);
    if ($raw === false || trim($raw) === '') return default_config();
    $data = json_decode($raw, true);
    return is_array($data) ? $data : default_config();
}

function save_config($config) {
    $json = json_encode(
        $config,
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT
    );
    if ($json === false) return false;
    return @file_put_contents(CONFIG_FILE, $json . PHP_EOL, LOCK_EX) !== false;
}

function open_db() {
    if (!is_file(DB_FILE)) return null;
    try {
        $pdo = new PDO('sqlite:' . DB_FILE);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $pdo->exec('PRAGMA busy_timeout = 5000');
        return $pdo;
    } catch (Exception $e) {
        return null;
    }
}

function csrf_token() {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(24));
    }
    return $_SESSION['csrf'];
}

function csrf_ok() {
    return isset($_POST['csrf'], $_SESSION['csrf'])
        && hash_equals((string)$_SESSION['csrf'], (string)$_POST['csrf']);
}

if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: admin.php');
    exit;
}

$login_error = '';
if (empty($_SESSION['admin_ok'])) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login_password'])) {
        if (hash_equals(ADMIN_PASSWORD, (string)$_POST['login_password'])) {
            $_SESSION['admin_ok'] = 1;
            csrf_token();
            header('Location: admin.php');
            exit;
        }
        $login_error = '密码错误';
    }
?>
<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>DiyVod 订阅者后台登录</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#090909;color:#eee;font-family:Arial,"Microsoft YaHei",sans-serif}
.login{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px}
.box{width:100%;max-width:380px;background:#151515;border:1px solid #2c2c2c;border-radius:16px;padding:28px}
h1{margin:0 0 8px;font-size:24px}.sub{font-size:13px;color:#888;margin-bottom:20px}
input{width:100%;height:44px;background:#0c0c0c;border:1px solid #333;border-radius:9px;color:#fff;padding:0 12px;outline:none}
button{width:100%;height:44px;margin-top:12px;border:0;border-radius:9px;background:#fff;color:#111;font-weight:700;cursor:pointer}
.err{color:#ff7b7b;font-size:13px;margin-top:10px}.tip{color:#777;font-size:12px;margin-top:12px}
</style>
</head>
<body>
<div class="login">
<form class="box" method="post">
<h1>DiyVod 订阅者后台</h1>
<div class="sub">请输入后台密码</div>
<input type="password" name="login_password" placeholder="后台密码" autofocus>
<button type="submit">登录</button>
<?php if ($login_error): ?><div class="err"><?php echo h($login_error); ?></div><?php endif; ?>
<div class="tip">默认密码：123456 （记得删除此处，以及修改密码）</div>
</form>
</div>
</body>
</html>
<?php
exit;
}

$flash = '';
$flash_type = 'ok';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_config'])) {
    if (!csrf_ok()) {
        $flash = '请求验证失败，请刷新页面后重试。';
        $flash_type = 'err';
    } else {
        $tanchuang = array();
        $imgs = isset($_POST['tc_img']) ? (array)$_POST['tc_img'] : array();
        $urls = isset($_POST['tc_url']) ? (array)$_POST['tc_url'] : array();
        $miaos = isset($_POST['tc_miao']) ? (array)$_POST['tc_miao'] : array();
        $max = max(count($imgs), count($urls), count($miaos));
        for ($i=0; $i<$max; $i++) {
            $img = trim(isset($imgs[$i]) ? $imgs[$i] : '');
            $url = trim(isset($urls[$i]) ? $urls[$i] : '');
            $miao = trim(isset($miaos[$i]) ? $miaos[$i] : '');
            if ($img === '' && $url === '' && $miao === '') continue;
            $tanchuang[] = array(
                'img' => $img,
                'url' => $url,
                'miao' => $miao === '' ? '5' : $miao
            );
        }

        $guanggao = array();
        $gimgs = isset($_POST['gg_img']) ? (array)$_POST['gg_img'] : array();
        $gurls = isset($_POST['gg_url']) ? (array)$_POST['gg_url'] : array();
        $max = max(count($gimgs), count($gurls));
        for ($i=0; $i<$max; $i++) {
            $img = trim(isset($gimgs[$i]) ? $gimgs[$i] : '');
            $url = trim(isset($gurls[$i]) ? $gurls[$i] : '');
            if ($img === '' && $url === '') continue;
            $guanggao[] = array('img' => $img, 'url' => $url);
        }

        $apiurl = array();
        $names = isset($_POST['api_name']) ? (array)$_POST['api_name'] : array();
        $aurls = isset($_POST['api_url']) ? (array)$_POST['api_url'] : array();
        $texts = isset($_POST['api_wenben']) ? (array)$_POST['api_wenben'] : array();
        $max = max(count($names), count($aurls), count($texts));
        for ($i=0; $i<$max; $i++) {
            $name = trim(isset($names[$i]) ? $names[$i] : '');
            $url = trim(isset($aurls[$i]) ? $aurls[$i] : '');
            $wenben = trim(isset($texts[$i]) ? $texts[$i] : '');
            if ($name === '' && $url === '' && $wenben === '') continue;
            $apiurl[] = array('name' => $name, 'url' => $url, 'wenben' => $wenben);
        }

        $config = array(
            'data' => array(
                'logo' => trim(isset($_POST['logo']) ? $_POST['logo'] : ''),
                'name' => trim(isset($_POST['name']) ? $_POST['name'] : 'DiyVod'),
                'weburl' => trim(isset($_POST['weburl']) ? $_POST['weburl'] : '')
            ),
            'tanchuang' => $tanchuang,
            'guanggao' => $guanggao,
            'apiurl' => $apiurl,
            'code' => 200,
            'msg' => 'success'
        );

        if (save_config($config)) {
            $flash = '配置保存成功';
        } else {
            $flash = '配置保存失败，请检查 config.json 写入权限';
            $flash_type = 'err';
        }
    }
}

$config = load_config();
$pdo = open_db();
$today = date('Y-m-d');
$online_from = date('Y-m-d H:i:s', time() - 15 * 60);

$total_users = 0;
$today_new = 0;
$today_used = 0;
$online_15m = 0;
$db_error = '';

if ($pdo) {
    try {
        $total_users = (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();

        $stmt = $pdo->prepare('SELECT COUNT(*) FROM users WHERE substr(first_use_at,1,10)=?');
        $stmt->execute(array($today));
        $today_new = (int)$stmt->fetchColumn();

        $stmt = $pdo->prepare('SELECT COUNT(*) FROM users WHERE last_use_date=?');
        $stmt->execute(array($today));
        $today_used = (int)$stmt->fetchColumn();

        $stmt = $pdo->prepare('SELECT COUNT(*) FROM users WHERE last_seen_at>=?');
        $stmt->execute(array($online_from));
        $online_15m = (int)$stmt->fetchColumn();
    } catch (Exception $e) {
        $db_error = '数据库结构不正确，请执行 diyvod.sql 重新建立。';
    }
} else {
    $db_error = '未找到 diyvod.sqlite，请先执行 diyvod.sql 创建数据库。';
}

$csrf = csrf_token();
?>
<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>DiyVod 订阅者后台</title>
<style>
:root{--bg:#090909;--card:#151515;--line:#2b2b2b;--text:#f1f1f1;--muted:#8a8a8a}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--text);font-family:Arial,"Microsoft YaHei",sans-serif}
.wrap{max-width:1280px;margin:auto;padding:22px}
.top{display:flex;align-items:center;justify-content:space-between;margin-bottom:18px}
.top h1{margin:0;font-size:24px}.top a{color:#aaa;text-decoration:none;font-size:13px}
.cards{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:18px}
.card,.panel{background:var(--card);border:1px solid var(--line);border-radius:14px}
.card{padding:18px}.card .lab{color:var(--muted);font-size:13px}.card .num{font-size:28px;font-weight:700;margin-top:7px}
.panel{margin-bottom:18px;overflow:hidden}.hd{padding:15px 18px;border-bottom:1px solid var(--line);font-weight:700}.body{padding:18px}
.notice{padding:11px 14px;border-radius:9px;margin-bottom:14px;font-size:13px}
.notice.ok{background:#12321d;color:#91efad}.notice.err{background:#3a1515;color:#ff9b9b}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.field label{display:block;font-size:12px;color:#aaa;margin-bottom:6px}
.field.full{grid-column:1/-1}
input[type=text],input[type=number]{width:100%;height:42px;background:#0d0d0d;border:1px solid #333;border-radius:9px;color:#fff;padding:0 11px;outline:none}
input:focus{border-color:#666}
.title{font-size:14px;margin:22px 0 9px;color:#ddd}
.desc{font-size:12px;color:#777;margin:-4px 0 10px;line-height:1.7}
.row{display:grid;gap:8px;margin-bottom:8px;align-items:center}
.row.tc{grid-template-columns:1.2fr 1.2fr 100px 70px}
.row.gg{grid-template-columns:1fr 1fr 70px}
.row.api{grid-template-columns:180px 1fr 1fr 70px}
.btn{border:1px solid #373737;border-radius:9px;background:#242424;color:#eee;padding:9px 13px;cursor:pointer}
.btn.del{background:#391717;border-color:#622626;color:#ff9b9b}
.save{background:#fff;color:#111;border:0;font-weight:700;padding:12px 24px}
.savebar{display:flex;justify-content:flex-end;margin-top:20px}
.tip{font-size:12px;color:#777;margin-top:5px}
@media(max-width:850px){
.cards{grid-template-columns:repeat(2,1fr)}.grid2{grid-template-columns:1fr}.field.full{grid-column:auto}
.row.tc,.row.gg,.row.api{grid-template-columns:1fr}.wrap{padding:12px}
}
</style>
</head>
<body>
<div class="wrap">
<div class="top">
  <div><h1>DiyVod 订阅者后台</h1><div class="tip">服务器时间：<?php echo h(date('Y-m-d H:i:s')); ?></div></div>
  <a href="?logout=1">退出登录</a>
</div>

<?php if ($flash): ?><div class="notice <?php echo h($flash_type); ?>"><?php echo h($flash); ?></div><?php endif; ?>
<?php if ($db_error): ?><div class="notice err"><?php echo h($db_error); ?></div><?php endif; ?>

<div class="cards">
  <div class="card"><div class="lab">总计用户</div><div class="num"><?php echo number_format($total_users); ?></div></div>
  <div class="card"><div class="lab">今日新增</div><div class="num"><?php echo number_format($today_new); ?></div></div>
  <div class="card"><div class="lab">今日使用</div><div class="num"><?php echo number_format($today_used); ?></div></div>
  <div class="card"><div class="lab">15分钟在线</div><div class="num"><?php echo number_format($online_15m); ?></div></div>
</div>

<form method="post">
<input type="hidden" name="csrf" value="<?php echo h($csrf); ?>">
<input type="hidden" name="save_config" value="1">

<div class="panel">
<div class="hd">订阅配置</div>
<div class="body">

<div class="title">基础配置</div>
<div class="desc">订阅者可配置 Logo、显示名称、网界地址。</div>
<div class="grid2">
  <div class="field"><label>APP Logo 图片地址</label><input type="text" name="logo" value="<?php echo h(isset($config['data']['logo'])?$config['data']['logo']:''); ?>"></div>
  <div class="field"><label>APP 显示名称</label><input type="text" name="name" value="<?php echo h(isset($config['data']['name'])?$config['data']['name']:'DiyVod'); ?>"></div>
  <div class="field full"><label>网界打开地址</label><input type="text" name="weburl" value="<?php echo h(isset($config['data']['weburl'])?$config['data']['weburl']:''); ?>"></div>
</div>

<div class="title">启动弹窗广告</div>
<div class="desc">图片地址 / 跳转地址 / 倒计时，支持多条，广告随机展示</div>
<div id="tcList">
<?php foreach ((array)(isset($config['tanchuang'])?$config['tanchuang']:array()) as $r): ?>
<div class="row tc">
  <input type="text" name="tc_img[]" value="<?php echo h(isset($r['img'])?$r['img']:''); ?>" placeholder="img 图片地址">
  <input type="text" name="tc_url[]" value="<?php echo h(isset($r['url'])?$r['url']:''); ?>" placeholder="url 跳转地址">
  <input type="number" name="tc_miao[]" value="<?php echo h(isset($r['miao'])?$r['miao']:'5'); ?>" placeholder="miao">
  <button class="btn del" type="button" onclick="delRow(this)">删除</button>
</div>
<?php endforeach; ?>
</div>
<button class="btn" type="button" onclick="addTc()">+ 新增弹窗广告</button>

<div class="title">横幅广告</div>
<div class="desc">图片地址 / 跳转地址。支持多条，播放列表广告随机展示，图片建议高度（78xp）</div>
<div id="ggList">
<?php foreach ((array)(isset($config['guanggao'])?$config['guanggao']:array()) as $r): ?>
<div class="row gg">
  <input type="text" name="gg_img[]" value="<?php echo h(isset($r['img'])?$r['img']:''); ?>" placeholder="img 图片地址">
  <input type="text" name="gg_url[]" value="<?php echo h(isset($r['url'])?$r['url']:''); ?>" placeholder="url 跳转地址">
  <button class="btn del" type="button" onclick="delRow(this)">删除</button>
</div>
<?php endforeach; ?>
</div>
<button class="btn" type="button" onclick="addGg()">+ 新增横幅广告</button>

<div class="title">API 资源</div>
<div class="desc">资源名称 / API 地址 / 资源介绍</div>
<div id="apiList">
<?php foreach ((array)(isset($config['apiurl'])?$config['apiurl']:array()) as $r): ?>
<div class="row api">
  <input type="text" name="api_name[]" value="<?php echo h(isset($r['name'])?$r['name']:''); ?>" placeholder="name 资源名称">
  <input type="text" name="api_url[]" value="<?php echo h(isset($r['url'])?$r['url']:''); ?>" placeholder="url API地址">
  <input type="text" name="api_wenben[]" value="<?php echo h(isset($r['wenben'])?$r['wenben']:''); ?>" placeholder="wenben 资源介绍">
  <button class="btn del" type="button" onclick="delRow(this)">删除</button>
</div>
<?php endforeach; ?>
</div>
<button class="btn" type="button" onclick="addApi()">+ 新增 API 资源</button>

<div class="savebar"><button class="btn save" type="submit">保存配置</button></div>
</div>
</div>
</form>
</div>

<script>
function delRow(btn){var row=btn.closest('.row');if(row)row.remove();}
function addTc(){
document.getElementById('tcList').insertAdjacentHTML('beforeend',
'<div class="row tc"><input type="text" name="tc_img[]" placeholder="img 图片地址"><input type="text" name="tc_url[]" placeholder="url 跳转地址"><input type="number" name="tc_miao[]" value="5" placeholder="miao"><button class="btn del" type="button" onclick="delRow(this)">删除</button></div>');
}
function addGg(){
document.getElementById('ggList').insertAdjacentHTML('beforeend',
'<div class="row gg"><input type="text" name="gg_img[]" placeholder="img 图片地址"><input type="text" name="gg_url[]" placeholder="url 跳转地址"><button class="btn del" type="button" onclick="delRow(this)">删除</button></div>');
}
function addApi(){
document.getElementById('apiList').insertAdjacentHTML('beforeend',
'<div class="row api"><input type="text" name="api_name[]" placeholder="name 资源名称"><input type="text" name="api_url[]" placeholder="url API地址"><input type="text" name="api_wenben[]" placeholder="wenben 资源介绍"><button class="btn del" type="button" onclick="delRow(this)">删除</button></div>');
}
</script>
</body>
</html>
